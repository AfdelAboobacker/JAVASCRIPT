const str ="hello";
const hassubstr=str.includes("ll");
console.log(hassubstr);
