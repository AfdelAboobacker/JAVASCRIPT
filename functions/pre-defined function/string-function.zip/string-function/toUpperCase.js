const str ="hello";
const upperstr= str.toUpperCase();
 console.log(upperstr);
 