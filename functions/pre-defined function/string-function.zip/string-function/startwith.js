const str="hello world";
const startwith=str.startsWith("hello");
console.log(startwith);