const str="HELLO";
const lowStr=str.toLowerCase();
console.log("original:"+str);

console.log("lowercased:"+lowStr);
