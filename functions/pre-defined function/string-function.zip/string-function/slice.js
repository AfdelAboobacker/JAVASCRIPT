const str="hello";
const sliceStr=str.slice(1,3);
console.log(sliceStr);
