const str="hello world";
const replse=str.replace("world","javascript");
console.log("original:"+str);
console.log("replaced:"+replse);