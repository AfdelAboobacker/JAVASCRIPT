const str="hello world";
const endWith=str.endsWith("world");
console.log(endWith);